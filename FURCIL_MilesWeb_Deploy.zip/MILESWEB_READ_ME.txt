====================================================================
           FURCIL — MILESWEB CPANEL DEPLOYMENT GUIDE
====================================================================

This ultra-lightweight (< 1MB) ZIP package contains everything pre-configured for MilesWeb cPanel hosting.

📁 ZIP CONTENTS INCLUDED:
- index.html, assets/, Images/ (Built React Frontend - Optimized under 1MB)
- .htaccess (Configured for SPA routing + backend pass-through)
- backend/ (PHP REST API + backend/.env with production credentials)
- database/ (cloudfashion.sql + migration_002 to 034 .sql files)

--------------------------------------------------------------------
STEP-BY-STEP DEPLOYMENT ON MILESWEB:
--------------------------------------------------------------------

1. UPLOAD TO CPANEL FILE MANAGER:
   - Login to MilesWeb cPanel.
   - Go to File Manager -> open 'public_html' directory.
   - Click Upload and select 'FURCIL_MilesWeb_Deploy.zip'.
   - Right click the uploaded zip -> Extract into 'public_html'.

2. CREATE DATABASE IN CPANEL:
   - Go to cPanel -> MySQL Database Wizard.
   - Create Database Name: cwhycofr_Furcil (or your preferred name).
   - Create Database User: cwhycofr_Furcil with Password: Furcil@12345 (or custom password).
   - Grant 'ALL PRIVILEGES' to the user.

3. IMPORT DATABASE IN PHPMYADMIN:
   - Open cPanel -> phpMyAdmin.
   - Select your database (cwhycofr_Furcil).
   - Click 'Import' -> Select 'database/cloudfashion.sql' from the extracted files -> Click Go.
   - Import all migration files from 'database/migration_*.sql' in order.

4. VERIFY / UPDATE BACKEND ENV CONFIG:
   - Go to File Manager -> public_html/backend/.env
   - Verify DB credentials match your cPanel MySQL user/pass:
       DB_HOST=localhost
       DB_NAME=cwhycofr_Furcil
       DB_USER=cwhycofr_Furcil
       DB_PASS=Furcil@12345
       APP_URL=https://yourdomain.com/backend
       FRONTEND_URL=https://yourdomain.com

5. TEST YOUR LIVE WEBSITE:
   - Visit https://yourdomain.com (Storefront & React SPA will load).
   - Visit https://yourdomain.com/admin/login (Admin panel).
   - Test backend API: https://yourdomain.com/backend/api/products

====================================================================