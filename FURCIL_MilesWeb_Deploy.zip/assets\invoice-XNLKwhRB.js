import{b as g}from"./browser-CjSdxGTc.js";import{l as n,p as c}from"./index-CNT94n-J.js";async function x(t){const s=window.open("","_blank","width=820,height=900");if(!s)return;s.document.write('<!doctype html><title>Invoice…</title><body style="font:14px Arial;padding:40px;color:#888">Generating invoice…</body>');const a=t.shipping_address||{},p=t.items.map(i=>`
    <tr>
      <td>${e(i.product_name)}${i.size?` <span class="muted">(${i.size}${i.color?", "+i.color:""})</span>`:""}</td>
      <td class="center">${i.quantity}</td>
      <td class="right">${n(i.price)}</td>
      <td class="right">${n(i.line_total)}</td>
    </tr>`).join(""),r=`${window.location.origin}/logo.png`;let d="";if(t.verify_token){const i=`${window.location.origin}/verify-order/${t.id}?t=${t.verify_token}`;let l="";try{l=await g.toDataURL(i,{width:150,margin:1,color:{dark:"#1a1a1a",light:"#ffffff"}})}catch{}l&&(d=`
    <div class="verify">
      <img src="${l}" alt="Verification QR" />
      <div>
        <div class="verify-title">Delivery Verification</div>
        <div class="muted">Scan to verify this order &amp; its items<br>against the live store record.</div>
      </div>
    </div>`)}const o=`<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>Invoice ${t.order_number}</title>
<style>
  * { font-family: 'Helvetica Neue', Arial, sans-serif; box-sizing: border-box; }
  body { margin: 0; padding: 40px; color: #1a1a1a; }
  .head { display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 3px solid #bf924d; padding-bottom: 18px; }
  .brand { height: 56px; width: auto; object-fit: contain; }
  .muted { color: #888; font-size: 12px; }
  h2 { margin: 0 0 4px; font-size: 14px; text-transform: uppercase; letter-spacing: 1px; color: #bf924d; }
  .cols { display: flex; justify-content: space-between; gap: 30px; margin: 26px 0; font-size: 13px; }
  table { width: 100%; border-collapse: collapse; margin-top: 10px; font-size: 13px; }
  th { text-align: left; background: #faf6ee; padding: 10px; border-bottom: 2px solid #eadbc0; }
  td { padding: 10px; border-bottom: 1px solid #eee; }
  .center { text-align: center; } .right { text-align: right; }
  .totals { width: 280px; margin-left: auto; margin-top: 18px; font-size: 13px; }
  .totals div { display: flex; justify-content: space-between; padding: 6px 0; }
  .totals .grand { border-top: 2px solid #bf924d; margin-top: 6px; padding-top: 10px; font-size: 17px; font-weight: 800; }
  .badge { display:inline-block; padding:3px 10px; border-radius:20px; background:#e7f6ec; color:#1a8a4a; font-size:12px; font-weight:600; }
  .below { display:flex; justify-content:space-between; align-items:flex-start; gap:24px; margin-top:18px; }
  .verify { display:flex; align-items:center; gap:14px; border:1px solid #eadbc0; background:#faf6ee; border-radius:10px; padding:12px 14px; max-width:340px; }
  .verify img { width:96px; height:96px; }
  .verify-title { font-weight:700; font-size:13px; color:#1a1a1a; margin-bottom:4px; text-transform:uppercase; letter-spacing:0.5px; }
  .foot { margin-top: 40px; text-align: center; color: #999; font-size: 12px; border-top: 1px solid #eee; padding-top: 16px; }
</style></head>
<body>
  <div class="head">
    <div>
      <img class="brand" src="${r}" alt="FURCIL" />
      <div class="muted" style="margin-top:6px">Premium pet care, curated for you.</div>
    </div>
    <div style="text-align:right">
      <div style="font-size:20px;font-weight:700">INVOICE</div>
      <div class="muted">#${t.order_number}</div>
      <div class="muted">${c(t.placed_at)}</div>
    </div>
  </div>

  <div class="cols">
    <div>
      <h2>Billed To</h2>
      <strong>${e(a.full_name||"")}</strong><br>
      ${e(a.line1||"")}${a.line2?", "+e(a.line2):""}<br>
      ${e(a.city||"")}, ${e(a.state||"")} - ${e(a.pincode||"")}<br>
      ${e(a.phone||"")}
    </div>
    <div style="text-align:right">
      <h2>Payment</h2>
      ${(t.payment_method||"").toUpperCase()}<br>
      <span class="badge">${t.payment_status}</span><br>
      <span class="muted">Status: ${t.status}</span>
    </div>
  </div>

  <table>
    <thead><tr><th>Item</th><th class="center">Qty</th><th class="right">Price</th><th class="right">Total</th></tr></thead>
    <tbody>${p}</tbody>
  </table>

  <div class="below">
    ${d}
    <div class="totals">
      <div><span>Subtotal</span><span>${n(t.subtotal)}</span></div>
      ${t.discount>0?`<div><span>Discount${t.coupon_code?" ("+t.coupon_code+")":""}</span><span>-${n(t.discount)}</span></div>`:""}
      <div><span>Shipping</span><span>${t.shipping_fee?n(t.shipping_fee):"Free"}</span></div>
      <div class="grand"><span>Total</span><span>${n(t.total)}</span></div>
    </div>
  </div>

  <div class="foot">Thank you for shopping with FURCIL · support@furcil.com</div>
  <script>window.onload = () => { window.print(); }<\/script>
</body></html>`;s.document.open(),s.document.write(o),s.document.close()}function f(t,s={}){const a=i=>n(i),p=(t.items||[]).map(i=>`
    <tr>
      <td>${e(i.product_name)}${i.sku?` <span class="muted">(${e(i.sku)})</span>`:""}</td>
      <td class="center">${i.quantity}</td>
      <td class="right">${a(i.price)}</td>
      <td class="right">${a(i.line_total)}</td>
    </tr>`).join(""),r=`${window.location.origin}/logo.png`,d=`<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>Invoice ${e(t.bill_number)}</title>
<style>
  * { font-family: 'Helvetica Neue', Arial, sans-serif; box-sizing: border-box; }
  body { margin: 0; padding: 40px; color: #1a1a1a; }
  .head { display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 3px solid #bf924d; padding-bottom: 18px; }
  .brand { height: 56px; width: auto; object-fit: contain; }
  .muted { color: #888; font-size: 12px; }
  h2 { margin: 0 0 4px; font-size: 14px; text-transform: uppercase; letter-spacing: 1px; color: #bf924d; }
  .cols { display: flex; justify-content: space-between; gap: 30px; margin: 26px 0; font-size: 13px; }
  table { width: 100%; border-collapse: collapse; margin-top: 10px; font-size: 13px; }
  th { text-align: left; background: #faf6ee; padding: 10px; border-bottom: 2px solid #eadbc0; }
  td { padding: 10px; border-bottom: 1px solid #eee; }
  .center { text-align: center; } .right { text-align: right; }
  .totals { width: 280px; margin-left: auto; margin-top: 18px; font-size: 13px; }
  .totals div { display: flex; justify-content: space-between; padding: 6px 0; }
  .totals .grand { border-top: 2px solid #bf924d; margin-top: 6px; padding-top: 10px; font-size: 17px; font-weight: 800; }
  .void { color:#e11d48; border:2px solid #e11d48; text-align:center; font-weight:700; padding:6px; margin:14px 0; border-radius:6px; }
  .foot { margin-top: 40px; text-align: center; color: #999; font-size: 12px; border-top: 1px solid #eee; padding-top: 16px; }
</style></head>
<body>
  <div class="head">
    <div>
      <img class="brand" src="${r}" alt="${e(s.store_name||"FURCIL")}" />
      <div class="muted" style="margin-top:6px">${e(s.address||"In-store purchase")}</div>
    </div>
    <div style="text-align:right">
      <div style="font-size:20px;font-weight:700">INVOICE</div>
      <div class="muted">#${e(t.bill_number)}</div>
      <div class="muted">${c(t.created_at)}</div>
    </div>
  </div>

  <div class="cols">
    <div>
      <h2>Billed To</h2>
      <strong>${e(t.customer_name||"Walk-in customer")}</strong><br>
      ${t.customer_phone?e(t.customer_phone)+"<br>":""}
      ${t.cashier?`<span class="muted">Cashier: ${e(t.cashier)}</span>`:""}
    </div>
    <div style="text-align:right">
      <h2>Payment</h2>
      ${e((t.payment_method||"").toUpperCase())}<br>
      <span class="muted">Counter sale</span>
    </div>
  </div>

  ${t.status==="void"?'<div class="void">VOID — items restocked</div>':""}

  <table>
    <thead><tr><th>Item</th><th class="center">Qty</th><th class="right">Price</th><th class="right">Total</th></tr></thead>
    <tbody>${p}</tbody>
  </table>

  <div class="totals">
    <div><span>Subtotal</span><span>${a(t.subtotal)}</span></div>
    ${t.discount>0?`<div><span>Discount</span><span>-${a(t.discount)}</span></div>`:""}
    ${t.tax_amount>0?`<div><span>Tax (${t.tax_pct}%)</span><span>${a(t.tax_amount)}</span></div>`:""}
    <div class="grand"><span>Total</span><span>${a(t.total)}</span></div>
    <div><span>Paid (${e(t.payment_method)})</span><span>${a(t.paid)}</span></div>
    ${t.payment_method==="split"?`<div class="muted"><span>&nbsp;&nbsp;Cash</span><span>${a(t.split_cash)}</span></div><div class="muted"><span>&nbsp;&nbsp;Card / UPI</span><span>${a(t.split_digital)}</span></div>`:""}
    ${t.change_due>0?`<div><span>Change</span><span>${a(t.change_due)}</span></div>`:""}
  </div>

  <div class="foot">${e(s.footer_note||"Thank you for shopping with us!")}</div>
  <script>window.onload = () => { window.print(); }<\/script>
</body></html>`,o=window.open("","_blank","width=820,height=900");o&&(o.document.write(d),o.document.close())}function e(t){return String(t??"").replace(/[&<>"']/g,s=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[s])}export{f as a,x as p};
